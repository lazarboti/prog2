class MyUtils {
    public static boolean isVowel(String s) {

        if (s.startsWith("a") || s.startsWith("A") || s.startsWith("e") || s.startsWith("E") || s.startsWith("i")
                || s.startsWith("I") || s.startsWith("o") || s.startsWith("O") || s.startsWith("u")
                || s.startsWith("U"))

        {
            return true;

        }
        return false;

    }
}