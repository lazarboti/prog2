
import java.util.Scanner;


public class Main
{
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Adjon meg egy mondatot:");
        String szavak = scanner.nextLine();
        if (szavak == "") 
        {
            System.err.println("Hiba! Egy mondatot kell megadni.");
            System.exit(1);
            
        }
        //else
        String[] tomb =szavak.split(" ");
        //System.out.println(Arrays.toString(tomb));
        System.out.print("Magánhangzóval kezdődő szavak: ");
        for(String szo :tomb)
        {
            
            boolean eredmeny = MyUtils.isVowel(szo);
            if (eredmeny == true) 
            {
                System.out.print(szo);
                System.out.print(", ");
                
            }
        }
        System.out.println("");
        System.out.print("Mássalhangzóval kezdődő szavak: ");
        for(String szo :tomb)
        {
            
            boolean eredmeny = MyUtils.isVowel(szo);
            if (eredmeny == false) 
            {
                System.out.print(szo);
                System.out.print(", ");
                
            }
        }
        System.out.println("");
    }
}