public class Main {
    public static void main(String[] args) {
        BirdRingData blueTit = new BirdRingData("H2000051501", "Cyanistes caeruleus", 5, 2, 12.5, 70.0);
        BirdRingData cormorant = new BirdRingData("H2000051503", "Phalacrocorax carbo", 6, 1, 35.0, 120.0);
        System.out.println(blueTit);
        System.out.println("");
        System.out.println(cormorant.getRingNumber());
        System.out.println(cormorant.getSpecies());
        System.out.println(cormorant.getFatScore());
        System.out.println(cormorant.getMuscleScore());
        System.out.println(cormorant.getWeight());
        System.out.println(cormorant.getWingLength());
        System.out.printf("%.2f\n",blueTit.calculateBodyConditionIndex());
        System.out.println(blueTit.assessHealthStatus());
        System.out.println(cormorant.assessHealthStatus());
    }
}