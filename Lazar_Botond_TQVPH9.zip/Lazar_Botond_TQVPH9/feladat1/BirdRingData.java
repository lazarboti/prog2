class BirdRingData
{
    private String  ringNumber;
    private String species;
    private double fatScore;
    private double muscleScore;
    private double weight;
    private double wingLength;

    public BirdRingData(String ringNumber, String species, double fatScore,double muscleScore, double weight, double wingLength)
    {
        this.ringNumber = ringNumber;
        this.species = species;
        this.fatScore = fatScore;
        this.muscleScore = muscleScore;
        this.weight = weight;
        this.wingLength = wingLength;

    }
    @Override
    public String toString()
    {
        return "Madárgyűrűzési adatok:\n- Gyűrűszám: "+ringNumber+"\n- Madárfaj: " +species+"\n- Zsir: "+fatScore+"\n- Izom: "+muscleScore+"\n- Tömeg: "+weight+" g\n- Szárnyhossz: "+wingLength+" mm\n";
    }
    public String getRingNumber()
    {
        return ringNumber;
    }
    public String getSpecies()
    {
        return species;
    }
    public double getFatScore()
    {
        return fatScore;
    }
    public double getMuscleScore()
    {
        return muscleScore;
    }
    public double getWeight()
    {
        return weight;

    }
    public double getWingLength()
    {
        return wingLength;
    }
    public double calculateBodyConditionIndex()
    {
        double index = -1;
        double cmWinglegth =wingLength;
        cmWinglegth =cmWinglegth/10;
        index = weight/(cmWinglegth*cmWinglegth);

        
        return index;
    }
    public String assessHealthStatus()
    {
        String eredmeny;
        if (fatScore <= 3 && muscleScore <= 1) 
        {
            eredmeny = "Alultáplált";
            return eredmeny;    
        }else if (fatScore <= 5 && muscleScore >= 2) 
        {
            eredmeny ="Egészséges";
            return eredmeny;    
        }else if (fatScore >= 6 ) 
        {
            eredmeny = "Túlsúlyos";
            return eredmeny;    
        } else
        {
            eredmeny = "Ismeretlen";
            return eredmeny;
        } 
    }


}