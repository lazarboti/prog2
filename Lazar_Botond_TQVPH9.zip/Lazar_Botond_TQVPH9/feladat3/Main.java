class MyUtils
{
    public static string sarkany(String[] csigolyak)
    {
        int counter = 0;
        
        for(String csigolya : csigolyak)
        {
            counter++;
            int osszeg = 0;
            char[] tomb =new char[csigolya.length()];
            for(int i = 0; i < tomb.length;i++)
            {
                tomb[i] = csigolya.substring(i);
            }
            for(int i = 0; i < tomb.length;i++)
            {
                int[] szamos = new int[3];
                szamos[i] = (int)tomb[i];

            }
            for(int elem : szamos)
            {
                osszeg =+elem;
            }
            if (osszeg <=15) 
            {
                return (String) counter;
            }

        }
        return "A sárkány sebezhetetlen";
    }

}


public class Main
{
    public static void main(String[] args) {
        if (args.length != 1) 
        {
            System.err.println("Hiba! Kérem adjon meg egy sárkány csigolyáit repreneztáló számsort(pl. 253_423_953_543");
            System.exit(1);

        }
        //else
        String gerinc = args[0];
        String[] csigolyak = gerinc.split("_");
         String eredmeny = MyUtils.sarkany(csigolyak);


    }
}