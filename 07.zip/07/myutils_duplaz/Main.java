import java.lang.Math;

public class Main
{
    public static void main(String[] args)
    {
        // Math myMath = new Math();
        // myMath.max(3, 6);

        System.out.println(Math.abs(-5));
        System.out.println(Math.max(20, 10));

        System.out.println(MyUtils.duplaz(6));
        System.out.println(MyUtils.strlen("hellóka"));
    }
}